using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Start_Animation : MonoBehaviour
{
    [SerializeField] private Animator m_Start;

    public void StartAnim()
    {
        m_Start.SetTrigger("Start");
    }
}
