using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Movement : MonoBehaviour
{
    [SerializeField] private float m_Speed;
    [SerializeField] private float m_AttackDistance;
    [SerializeField] private GameObject m_Shadow;
    [SerializeField] private float m_Weight;

    public bool m_IsAttacking;

    private Transform m_Target;
    private Enemy_Attack m_Attack;

    private bool m_CanAttack;

    private Animator m_Animation;
    private SpriteRenderer m_Sprite;

    private float m_Delay, m_MaxDelay = 0.5f;

    private Floor_Manager m_Floor;

    // Start is called before the first frame update
    void Start()
    {
        m_Target = GameObject.FindGameObjectWithTag("Player").transform;

        m_Attack = GetComponent<Enemy_Attack>();
        m_Animation = GetComponent<Animator>();
        m_Sprite = GetComponent<SpriteRenderer>();

        m_Animation.SetTrigger("Landed");

        m_Delay = m_MaxDelay;

        m_Shadow.SetActive(true);

        m_Floor = FindObjectOfType<Floor_Manager>();
        m_Floor.EnemyLanded(m_Weight);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void FixedUpdate()
    {
        if (Vector2.Distance(transform.position, m_Target.position) > m_AttackDistance & !m_IsAttacking)
        {
            if (m_Delay >= m_MaxDelay)
            {
                transform.position = Vector2.MoveTowards(transform.position, m_Target.position, m_Speed * Time.deltaTime);
                m_Animation.SetBool("Walking", true);
            }

            m_CanAttack = false;
        }

        else
        {
            m_CanAttack = true;
            m_Delay = 0;
            m_Animation.SetBool("Walking", false);
        }

        if (m_Target.position.x > transform.position.x)
        {
            m_Sprite.flipX = false;
        }

        else
        {
            m_Sprite.flipX = true;
        }

        m_Attack.CanAttack(m_CanAttack);

        if (m_Delay < m_MaxDelay)
        {
            m_Delay += 1 * Time.deltaTime;
        }
    }
}
