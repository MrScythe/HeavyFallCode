using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Enemy_Spawn : MonoBehaviour
{
    [SerializeField] private Transform m_Spawn1, m_Target1, m_Spawn2, m_Target2;
    [SerializeField] private Transform m_Target1_1, m_Target1_2, m_Target2_1, m_Target2_2;
    [SerializeField] private GameObject[] m_Enemy;
    [SerializeField] private GameObject m_Robot, m_Stone;

    [SerializeField] private float m_SpawnSpeed;

    [SerializeField] private Text m_Text;

    private GameObject m_SpawnedEnemy;
    private float m_MaxDistance, m_Distance;
    private Transform m_Spawn, m_Target;

    private int m_TotalEnemies = 1000;
    private bool m_CanSpawn = true;

    private int m_EnemyCount;

    private float m_TargetY, m_Target1Y, m_Target2Y;
    private float m_Target1Y_1, m_Target1Y_2, m_Target2Y_1, m_Target2Y_2;

    private float m_EmitSpeed;

    private bool m_RobotB, m_StoneB, m_NoCooldown, m_NoLimit;

    // Start is called before the first frame update
    void Start()
    {
        m_Text.text = "Enemies: " + m_TotalEnemies;

        m_Target1Y = m_Target1.position.y;
        m_Target2Y = m_Target2.position.y;

        m_Target1Y_1 = m_Target1_1.position.y;
        m_Target1Y_2 = m_Target1_2.position.y;
        m_Target2Y_1 = m_Target2_1.position.y;
        m_Target2Y_2 = m_Target2_2.position.y;
    }

    public void RobotOnly()
    {
        m_RobotB = true;
    }

    public void StoneOnly()
    {
        m_StoneB = true;
    }

    public void NoCooldown()
    {
        m_NoCooldown = true;
    }

    public void NoLimit()
    {
        m_NoLimit = true;
    }

    public void EventStop()
    {
        m_RobotB = false;
        m_StoneB = false;
        m_NoCooldown = false;
        m_NoLimit = false;
    }

    // Update is called once per frame
    void Update()
    {
        m_EnemyCount = GameObject.FindGameObjectsWithTag("Enemy").Length;

        if ((m_EnemyCount < 5 || m_NoLimit) && (m_CanSpawn || m_NoCooldown) && m_EmitSpeed <= 0)
        {
            m_EmitSpeed = Random.Range(0f, 2f);

            m_TotalEnemies--;
            m_Text.text = "Enemies: " + m_TotalEnemies;
            m_CanSpawn = false;

            int spawn = Random.Range(0, 2);

            if (spawn == 0)
            {
                m_Spawn = m_Spawn1;

                int target = Random.Range(0, 3);
                if (target == 0)
                {
                    m_Target = m_Target1;
                    m_TargetY = m_Target1Y;
                }

                else if (target == 1)
                {
                    m_Target = m_Target1_1;
                    m_TargetY = m_Target1Y_1;
                }

                else
                {
                    m_Target = m_Target1_2;
                    m_TargetY = m_Target1Y_2;
                }
            }

            else
            {
                m_Spawn = m_Spawn2;

                int target = Random.Range(0, 3);
                if (target == 0)
                {
                    m_Target = m_Target2;
                    m_TargetY = m_Target2Y;
                }

                else if (target == 1)
                {
                    m_Target = m_Target2_1;
                    m_TargetY = m_Target2Y_1;
                }

                else
                {
                    m_Target = m_Target2_2;
                    m_TargetY = m_Target2Y_2;
                }
            }

            m_MaxDistance = Vector2.Distance(m_Spawn.position, m_Target.position);

            if (m_RobotB)
            {
                m_SpawnedEnemy = Instantiate(m_Robot, m_Spawn.position, Quaternion.identity);
            }

            else if (m_StoneB)
            {
                m_SpawnedEnemy = Instantiate(m_Stone, m_Spawn.position, Quaternion.identity);
            }

            else
            {
                int enemyType = Random.Range(0, 20);

                if (enemyType < 15)
                {
                    m_SpawnedEnemy = Instantiate(m_Enemy[0], m_Spawn.position, Quaternion.identity);
                }

                else if (enemyType < 18)
                {
                    m_SpawnedEnemy = Instantiate(m_Enemy[1], m_Spawn.position, Quaternion.identity);
                }

                else
                {
                    m_SpawnedEnemy = Instantiate(m_Enemy[2], m_Spawn.position, Quaternion.identity);
                }
            }

            SpriteRenderer sprite = m_SpawnedEnemy.GetComponent<SpriteRenderer>();

            if (spawn == 0)
            {
                sprite.flipX = false;
            }

            else
            {
                sprite.flipX = true;
            }

            m_SpawnedEnemy.GetComponent<Enemy_Movement>().enabled = false;
            m_SpawnedEnemy.GetComponent<Enemy_Attack>().enabled = false;
            m_SpawnedEnemy.GetComponent<Enemy_Stats>().enabled = false;

            m_Distance = m_MaxDistance / m_MaxDistance;
        }

        if (m_SpawnedEnemy != null)
        {
            if (m_SpawnedEnemy.transform.position != m_Target.position)
            {
                if (m_Distance > 0)
                {
                    m_Distance -= m_SpawnSpeed * Time.deltaTime;
                }

                m_Target.position = new Vector2(m_Target.position.x, (m_TargetY + m_Distance) * 10);

                m_SpawnedEnemy.transform.position = Vector2.Lerp(m_Target.position, m_Spawn.position, m_Distance);
                //m_SpawnedEnemy.transform.position = Vector2.MoveTowards(m_SpawnedEnemy.transform.position, m_Target.position, 5f * Time.deltaTime);
            }

            else
            {
                m_SpawnedEnemy.GetComponent<Enemy_Movement>().enabled = true;
                m_SpawnedEnemy.GetComponent<Enemy_Attack>().enabled = true;
                m_SpawnedEnemy.GetComponent<Enemy_Stats>().enabled = true;

                m_SpawnedEnemy = null;

                m_CanSpawn = true;
            }
        }

        if (m_EmitSpeed > 0)
        {
            m_EmitSpeed -= 1 * Time.deltaTime;
        }
    }

    public void NoSpawn()
    {
        gameObject.GetComponent<Enemy_Spawn>().enabled = false;
        GetComponent<Floor_Manager>().StopElevator();
    }
}
