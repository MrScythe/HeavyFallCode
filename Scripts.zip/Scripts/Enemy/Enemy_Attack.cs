using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Attack : MonoBehaviour
{
    [SerializeField] private float m_MaxAttackDelay;

    [SerializeField] private Transform m_Pivot, m_Emitter;
    [SerializeField] private GameObject m_Attack;

    [SerializeField] private AudioSource m_Shoot, m_Land;

    private Floor_Manager m_Floor;

    private float m_AttackDelay;
    private bool m_CanAttack;

    private Transform m_Target;

    private Animator m_Animation, m_VcamAnim;
    private Enemy_Movement m_Movement;

    private bool m_IsAttacking = false;

    // Start is called before the first frame update
    void Start()
    {
        m_Target = GameObject.FindGameObjectWithTag("Player").transform;
        m_VcamAnim = GameObject.FindGameObjectWithTag("Vcam").GetComponent<Animator>();

        m_Floor = FindObjectOfType<Floor_Manager>();

        m_Animation = GetComponent<Animator>();
        m_Movement = GetComponent<Enemy_Movement>();

        m_AttackDelay = m_MaxAttackDelay;

        if (m_Land != null)
        {
            m_Land.Play();
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (m_AttackDelay < m_MaxAttackDelay)
        {
            m_AttackDelay += 1 * Time.deltaTime;
        }

        else if (m_CanAttack)
        {
            m_AttackDelay = 0;

            m_Animation.SetTrigger("Attack");

            m_Movement.m_IsAttacking = true;
            m_IsAttacking = true;
        }
    }

    public void CanAttack(bool canAttack)
    {
        m_CanAttack = canAttack;
    }

    public void Attack()
    {
        GameObject attack = Instantiate(m_Attack, m_Emitter.position, m_Emitter.rotation);
        Destroy(attack, 1f);

        m_Movement.m_IsAttacking = false;
        m_IsAttacking = false;

        if (m_Shoot != null)
        {
            m_Shoot.Play();
        }
    }

    public void LandAttack()
    {
        transform.position = m_Target.position;
    }

    public void HasLanded()
    {
        m_Floor.EnemyLanded(10f);

        if (m_Land != null)
        {
            m_Land.Play();
        }
    }

    private void FixedUpdate()
    {
        if (!m_IsAttacking)
        {
            Vector3 lookAt = m_Target.position;

            float AngleRad = Mathf.Atan2(lookAt.y - m_Pivot.position.y, lookAt.x - m_Pivot.position.x);

            float AngleDeg = (180 / Mathf.PI) * AngleRad;

            m_Pivot.rotation = Quaternion.Euler(0, 0, AngleDeg);
        }
    }
}
