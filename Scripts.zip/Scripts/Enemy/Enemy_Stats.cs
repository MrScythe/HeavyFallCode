using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Enemy_Stats : MonoBehaviour
{
    [SerializeField] private int m_MaxHealth;
    [SerializeField] private Slider m_Healthbar;

    [SerializeField] private Color m_HighHealth, m_LowHealth;
    [SerializeField] private Image m_BarColor;
    [SerializeField] private GameObject m_Explosion;

    [SerializeField] private AudioSource m_Hit, m_Dead;

    private int m_Health;

    private Rigidbody2D m_Rigidbody;
    private float m_Knockback = 2;

    private Enemy_Movement m_Movement;
    private Enemy_Attack m_Attack;
    private Animator m_Animation;

    private float m_StunDelay, m_MaxStunDelay = 0.2f;

    private SpriteRenderer m_Sprite;
    private float m_Hurt = 1;
    
    // Start is called before the first frame update
    void Start()
    {
        m_Rigidbody = GetComponent<Rigidbody2D>();
        m_Movement = GetComponent<Enemy_Movement>();
        m_Attack = GetComponent<Enemy_Attack>();
        m_Animation = GetComponent<Animator>();
        m_Sprite = GetComponent<SpriteRenderer>();

        m_Health = m_MaxHealth;
        m_StunDelay = m_MaxStunDelay;

        m_Healthbar.gameObject.SetActive(true);
        m_Healthbar.maxValue = m_MaxHealth;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Melee"))
        {
            m_Hit.Play();

            m_Hurt = 0;

            if (m_Movement != null)
            {
                m_Movement.enabled = false;
            }

            if (m_Attack != null)
            {
                m_Attack.enabled = false;
            }

            m_StunDelay = 0;

            m_Rigidbody.AddForce(collision.gameObject.transform.right * m_Knockback, ForceMode2D.Impulse);
            m_Health--;

            if (m_Health <= 0)
            {
                m_Hurt = 1;

                Destroy(gameObject, 0.5f);
                m_Animation.SetTrigger("Dead");

                m_Rigidbody.AddForce(collision.gameObject.transform.right * 75, ForceMode2D.Impulse);

                GetComponent<BoxCollider2D>().enabled = false;

                m_Rigidbody.drag = 0;

                m_Dead.Play();
            }
        }

        if (collision.CompareTag("Bullet"))
        {
            m_Hit.Play();

            GameObject fire = Instantiate(m_Explosion, transform.position, Quaternion.identity);
            Destroy(fire, 0.5f);

            Destroy(collision.gameObject);

            m_Health -= 6;

            if (m_Health <= 0)
            {
                m_Hurt = 1;

                Destroy(gameObject, 0.5f);
                m_Animation.SetTrigger("Dead");

                m_Rigidbody.AddForce(collision.gameObject.transform.right * 75, ForceMode2D.Impulse);

                GetComponent<BoxCollider2D>().enabled = false;

                m_Rigidbody.drag = 0;

                m_Dead.Play();
            }
        }
    }

    public void GameOver()
    {
        m_Hurt = 1;

        Destroy(gameObject, 0.5f);
        m_Animation.SetTrigger("Dead");

        m_Rigidbody.AddForce(transform.up * 50, ForceMode2D.Impulse);

        GetComponent<BoxCollider2D>().enabled = false;

        m_Rigidbody.drag = 0;
    }

    // Update is called once per frame
    void Update()
    {
        m_Sprite.color = new Color(1, m_Hurt, m_Hurt);

        if (m_Hurt < 1)
        {
            m_Hurt += 5 * Time.deltaTime;
        }

        m_Healthbar.value = m_Health;

        if (m_Health > m_MaxHealth / 2)
        {
            m_BarColor.color = m_HighHealth;
        }

        else
        {
            m_BarColor.color = m_LowHealth;
        }

        if (m_StunDelay < m_MaxStunDelay)
        {
            m_StunDelay += 1 * Time.deltaTime;
        }

        else
        {
            m_Movement.enabled = true;
            m_Attack.enabled = true;
        }
    }
}
