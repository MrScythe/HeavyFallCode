using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Movement : MonoBehaviour
{
    [SerializeField] private float m_Speed;
    private Animator m_Animation;

    // Use this for initialization
    void Start()
    {
        m_Animation = GetComponent<Animator>();
    }

    private void Update()
    {

    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (Input.GetAxisRaw("Horizontal") != 0)
        {
            if (Input.GetAxisRaw("Horizontal") > 0)
            {
                transform.Translate(Vector3.right * m_Speed * Time.deltaTime, Space.World);
            }

            else if (Input.GetAxisRaw("Horizontal") < 0)
            {
                transform.Translate(Vector3.left * m_Speed * Time.deltaTime, Space.World);
            }
        }

        if (Input.GetAxisRaw("Vertical") != 0)
        {
            if (Input.GetAxisRaw("Vertical") > 0)
            {
                transform.Translate(Vector3.up * m_Speed * Time.deltaTime, Space.World);
            }

            else if (Input.GetAxisRaw("Vertical") < 0)
            {
                transform.Translate(Vector3.down * m_Speed * Time.deltaTime, Space.World);
            }
        }

        if (Input.GetAxisRaw("Horizontal") != 0 || Input.GetAxisRaw("Vertical") != 0)
        {
            m_Animation.SetBool("Walking", true);
        }

        else
        {
            m_Animation.SetBool("Walking", false);
        }
    }
}
