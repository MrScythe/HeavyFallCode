using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Attack : MonoBehaviour
{
    [SerializeField] private float m_AttackForce;
    [SerializeField] private Transform m_Emitter, m_EmitterFire;
    [SerializeField] private GameObject m_Melee, m_Bullet;

    [SerializeField] private AudioSource m_Shoot, m_Swing;

    private Animator m_Animation;

    private Rigidbody2D m_Rigidbody;

    private float m_AttackDelay, m_MaxAttackDelay = 0.15f;
    private float m_MoveDelay, m_MaxMoveDelay = 0.3f;
    private Player_Movement m_Movement;

    private bool m_Attacks;
    private bool m_Casting;

    // Start is called before the first frame update
    void Start()
    {
        m_Rigidbody = GetComponent<Rigidbody2D>();
        m_Movement = GetComponent<Player_Movement>();
        m_Animation = GetComponent<Animator>();

        m_AttackDelay = m_MaxAttackDelay;
        m_MoveDelay = m_MaxMoveDelay;
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 mouseScreenPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        if (m_AttackDelay < m_MaxAttackDelay)
        {
            m_AttackDelay += 1 * Time.deltaTime;
        }

        else if (Input.GetMouseButtonDown(0) && !m_Casting)
        {
            m_Swing.Play();

            m_Attacks = !m_Attacks;

            if (m_Attacks)
            {
                m_Animation.SetTrigger("Attack");
            }

            else
            {
                m_Animation.SetTrigger("Attack2");
            }

            m_AttackDelay = 0;

            GameObject melee = Instantiate(m_Melee, m_Emitter.position, m_Emitter.rotation);
            Destroy(melee, 0.2f);

            m_Rigidbody.AddForce((mouseScreenPosition - transform.position) * m_AttackForce, ForceMode2D.Impulse);

            m_MoveDelay = 0;
            m_Movement.enabled = false;
        }

        if (Input.GetMouseButtonDown(1) && !m_Casting)
        {
            m_Animation.SetTrigger("Fire");
            m_Casting = true;
        }

        if (m_MoveDelay < m_MaxMoveDelay)
        {
            m_MoveDelay += 1 * Time.deltaTime;
        }

        else if (m_Casting)
        {
            m_Movement.enabled = false;
        }
        
        else
        {
            m_Movement.enabled = true;
        }
    }

    public void ShootFire()
    {
        GameObject bullet = Instantiate(m_Bullet, m_EmitterFire.position, m_EmitterFire.rotation);
        Destroy(bullet, 1f);
        m_Casting = false;

        m_Shoot.Play();
    }
}
