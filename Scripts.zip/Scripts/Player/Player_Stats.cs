using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player_Stats : MonoBehaviour
{
    [SerializeField] private float m_MaxHealth;
    [SerializeField] private GameObject m_Explode;

    [SerializeField] private Slider m_Healthbar;
    [SerializeField] private Color m_HighHealth, m_LowHealth;
    [SerializeField] private Image m_BarColor;

    [SerializeField] private AudioSource m_Hurt;

    private float m_Health;

    private bool m_GameOver;

    // Start is called before the first frame update
    void Start()
    {
        m_Health = m_MaxHealth;

        m_Healthbar.maxValue = m_MaxHealth;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Projectile"))
        {
            Destroy(collision.gameObject);

            GameObject ex = Instantiate(m_Explode, transform.position, Quaternion.identity);
            Destroy(ex, 0.5f);

            m_Health--;

            m_Hurt.Play();
        }

        if (collision.CompareTag("Damage"))
        {
            m_Health--;

            m_Hurt.Play();
        }

        if (collision.CompareTag("Enemy"))
        {
            m_Health -= 2;

            m_Hurt.Play();
        }
    }

    // Update is called once per frame
    void Update()
    {
        m_Healthbar.value = m_Health;

        if (m_Health > m_MaxHealth / 3)
        {
            m_BarColor.color = m_HighHealth;
        }

        else
        {
            m_BarColor.color = m_LowHealth;
        }

        if (m_Health <= 0)
        {
            if (!m_GameOver)
            {
                m_GameOver = true;

                FindObjectOfType<Enemy_Spawn>().NoSpawn();
                FindObjectOfType<FollowMouse>().enabled = false;

                GetComponent<Animator>().SetTrigger("Dead");

                GetComponent<Player_Movement>().enabled = false;
                GetComponent<Player_Attack>().enabled = false;

                m_Healthbar.gameObject.SetActive(false);
            }

            Enemy_Stats[] enemies = FindObjectsOfType<Enemy_Stats>();

            for (int i = 0; i < enemies.Length; i++)
            {
                enemies[i].GameOver();
            }
        }
    }
}
