using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowMouse : MonoBehaviour
{
    [SerializeField] private Transform m_Pivot;
    private SpriteRenderer m_PlayerSprite;

    private void Start()
    {
        m_PlayerSprite = GetComponent<SpriteRenderer>();
    }

    void FixedUpdate()
    {
        Vector3 mouseScreenPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        Vector3 lookAt = mouseScreenPosition;

        float AngleRad = Mathf.Atan2(lookAt.y - m_Pivot.position.y, lookAt.x - m_Pivot.position.x);

        float AngleDeg = (180 / Mathf.PI) * AngleRad;

        m_Pivot.rotation = Quaternion.Euler(0, 0, AngleDeg);
        
        if (mouseScreenPosition.x > transform.position.x)
        {
            m_PlayerSprite.flipX = false;
        }

        else
        {
            m_PlayerSprite.flipX = true;
        }
    }
}
