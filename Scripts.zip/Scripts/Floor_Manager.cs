using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Floor_Manager : MonoBehaviour
{
    [SerializeField] private Text m_FloorText, m_VelocityText, m_EventText;
    [SerializeField] private Animator m_Background;
    [SerializeField] private GameObject m_Effect;

    [SerializeField] private Animator m_Forground;
    [SerializeField] private Animator m_Camera, m_CameraGroup;

    [SerializeField] private Animator m_Sign, m_Flash;

    [SerializeField] private Text m_FloorReached, m_HighscoreText;

    [SerializeField] private AudioSource m_EventSound, m_Deathsplosion;

    private float m_Delay, m_MaxDelay = 10;

    private float m_CurrentFloor = 1, m_Velocity = 0.5f;

    private bool m_Event = false;
    private int m_EventType;
    private float m_EventDuration, m_DurationMax = 10;

    private Enemy_Spawn m_Spawn;

    private bool m_GameOver;

    private float m_FallSpeed = 1;

    private int m_HighScore;

    // Start is called before the first frame update
    void Start()
    {
        m_Spawn = GetComponent<Enemy_Spawn>();

        m_Effect.SetActive(false);
        m_EventDuration = m_DurationMax;

        m_HighScore = PlayerPrefs.GetInt("Score");
    }

    public void EnemyLanded(float weight)
    {
        m_Velocity += weight / 10;

        if (weight >= 5)
        {
            if (weight >= 10)
            {
                m_CameraGroup.SetTrigger("HeavyShake");
            }

            else
            {
                m_CameraGroup.SetTrigger("Shake");
            }
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (!m_GameOver)
        {
            m_FloorText.text = "" + (int)m_CurrentFloor;
            m_VelocityText.text = "Velocity: " + ((int)m_Velocity + 1);

            m_CurrentFloor += m_Velocity * Time.deltaTime;

            if (m_Background.speed <= 10)
            {
                m_Background.speed = m_Velocity / 2;
                m_Forground.speed = m_Velocity / 5;
            }

            else
            {
                m_Background.speed = 10;
                m_Forground.speed = 5;
            }

            if (m_Velocity > 10)
            {
                m_Effect.SetActive(true);
                m_Camera.SetTrigger("Fast");
            }

            if (m_Delay <= m_MaxDelay)
            {
                m_Delay += 1 * Time.deltaTime;
            }

            else
            {
                m_Forground.SetTrigger("Go");
                m_Delay = 0;
            }

            if ((int)(m_CurrentFloor % 200) == 0 && !m_Event)
            {
                m_EventSound.Play();

                m_Event = true;
                m_EventDuration = 0;

                m_Sign.SetTrigger("Go");

                m_EventType = Random.Range(0, 3);

                switch (m_EventType)
                {
                    case 0:
                        m_EventText.text = "ROBOTS ONLY?!";
                        m_Spawn.RobotOnly();
                        break;

                    case 1:
                        m_EventText.text = "NO LIMIT?!";
                        m_Spawn.NoLimit();
                        break;
                    /*
                    case 2:
                        m_EventText.text = "THEY KEEP COMING!!";
                        m_Spawn.NoCooldown();
                        break;
                    */
                    default:
                        m_EventText.text = "GET STOMPED! HAHA!!";
                        m_Spawn.StoneOnly();
                        break;
                }
            }

            if (m_EventDuration < m_DurationMax)
            {
                m_EventDuration += 1 * Time.deltaTime;
                m_Event = true;
            }

            else if (m_Event)
            {
                m_Event = false;

                m_Sign.SetTrigger("Bye");

                m_Spawn.EventStop();
            }
        }

        else
        {
            if (m_Velocity < 500)
            {
                m_Velocity += m_FallSpeed * Time.deltaTime;
                m_FallSpeed++;

                m_Background.speed = m_Velocity / 2;
                m_Forground.speed = m_Velocity / 5;
            }

            else
            {
                m_Flash.SetTrigger("Dead");
            }
        }
    }

    public void StopElevator()
    {
        m_GameOver = true;

        m_FloorReached.text = "Depth Reached: " + (int)m_CurrentFloor;

        if ((int)m_CurrentFloor > m_HighScore)
        {
            PlayerPrefs.SetInt("Score", (int)m_CurrentFloor);
            m_HighScore = ((int)m_CurrentFloor);
        }

        m_HighscoreText.text = "Lowest Depth: " + m_HighScore;

        if (m_Event)
        {
            m_Sign.SetTrigger("Bye");
        }

        if (m_Background.speed <= 10)
        {
            m_Velocity = 10;

            m_Background.speed = m_Velocity / 2;
            m_Forground.speed = m_Velocity / 5;

            m_Effect.SetActive(true);
            m_Camera.SetTrigger("Fast");

            m_CameraGroup.SetTrigger("HeavyShake");

            m_Deathsplosion.Play();
        }
    }
}
