using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BG_Speed : MonoBehaviour
{
    [SerializeField] private Animator m_BG;

    private bool m_Start;
    private float m_Speed = 1;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    public void StartBG()
    {
        m_Start = true;
    }

    // Update is called once per frame
    void Update()
    {
        if (m_Start)
        {
            m_BG.speed += m_Speed * Time.deltaTime;
            m_Speed += 0.1f;
        }
    }
}
