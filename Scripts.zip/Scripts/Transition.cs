using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Transition : MonoBehaviour
{
    [SerializeField] private Animator m_Transition;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    public void StartTransition()
    {
        m_Transition.SetTrigger("On");
    }

    public void MenuTransition()
    {
        m_Transition.SetTrigger("Menu");
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
