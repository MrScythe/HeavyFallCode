using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Score : MonoBehaviour
{
    [SerializeField] private Text m_Text;
    private int m_HighScore;

    // Start is called before the first frame update
    void Start()
    {
        m_HighScore = PlayerPrefs.GetInt("Score");
        m_Text.text = "" + m_HighScore;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
